<?php
declare(strict_types=1);

/**
 * Admissions Page
 * 
 * @package SathyaSaiSchool
 */

// Include necessary configuration and header
require_once 'includes/config.php';
require_once 'includes/header.php';
?>

<main class="admissions-page">
    <!-- Page Title -->
    <section class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Admissions</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= SITE_URL ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Admissions</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section>

    <!-- Welcome Section -->
    <section class="welcome-section py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <h2 class="section-title">Join Our Family</h2>
                    <p class="lead mb-4">We welcome learners from all backgrounds who seek an education rooted in strong moral values and academic excellence.</p>
                    <p>At Sathya Sai School Chatsworth, we believe in providing quality education that nurtures both academic excellence and character development. Our admissions process is designed to be inclusive and supportive, ensuring that every child has the opportunity to benefit from our unique educational approach.</p>
                </div>
                <div class="col-lg-6">
                    <div class="image-container">
                        <img src="<?= SITE_URL ?>/assets/images/admissions-hero.jpg" alt="Students at Sathya Sai School" class="img-fluid rounded shadow">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Requirements Section -->
    <section class="requirements-section py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2 class="section-title text-center">Admission Requirements</h2>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="requirements-card h-100">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title h4 mb-4">Eligibility Criteria</h3>
                                <ul class="requirements-list">
                                    <li>
                                        <i class="fa-solid fa-check text-primary me-2"></i>
                                        Open to all students regardless of religion, race, or socio-economic background
                                    </li>
                                    <li>
                                        <i class="fa-solid fa-check text-primary me-2"></i>
                                        Completion of registration forms and commitment to the school's values
                                    </li>
                                    <li>
                                        <i class="fa-solid fa-check text-primary me-2"></i>
                                        Interview and assessment for appropriate grade placement
                                    </li>
                                    <li>
                                        <i class="fa-solid fa-check text-primary me-2"></i>
                                        Affordable levy structure with support available for indigent learners
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="requirements-card h-100">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title h4 mb-4">Required Documents</h3>
                                <ul class="requirements-list">
                                    <li>
                                        <i class="fa-solid fa-file-lines text-primary me-2"></i>
                                        Completed application form
                                    </li>
                                    <li>
                                        <i class="fa-solid fa-file-lines text-primary me-2"></i>
                                        Copy of learner's birth certificate
                                    </li>
                                    <li>
                                        <i class="fa-solid fa-file-lines text-primary me-2"></i>
                                        Most recent school reports
                                    </li>
                                    <li>
                                        <i class="fa-solid fa-file-lines text-primary me-2"></i>
                                        Transfer card from previous school (if applicable)
                                    </li>
                                    <li>
                                        <i class="fa-solid fa-file-lines text-primary me-2"></i>
                                        Parents' ID documents
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Process Section -->
    <section class="process-section py-5">
        <div class="container">
            <h2 class="section-title text-center mb-5">Admissions Process</h2>
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="process-step text-center">
                        <div class="process-icon mb-3">
                            <i class="fa-solid fa-file-pen fa-2x text-primary"></i>
                        </div>
                        <h3 class="h5">1. Application</h3>
                        <p>Submit completed application form with all required documents</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="process-step text-center">
                        <div class="process-icon mb-3">
                            <i class="fa-solid fa-clipboard-check fa-2x text-primary"></i>
                        </div>
                        <h3 class="h5">2. Assessment</h3>
                        <p>Complete placement assessment and family interview</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="process-step text-center">
                        <div class="process-icon mb-3">
                            <i class="fa-solid fa-envelope-open-text fa-2x text-primary"></i>
                        </div>
                        <h3 class="h5">3. Acceptance</h3>
                        <p>Receive acceptance letter and welcome package</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="process-step text-center">
                        <div class="process-icon mb-3">
                            <i class="fa-solid fa-handshake fa-2x text-primary"></i>
                        </div>
                        <h3 class="h5">4. Enrollment</h3>
                        <p>Complete enrollment process and orientation</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="cta-section py-5 bg-primary text-white">
        <div class="container text-center">
            <h2 class="mb-4">Begin Your Journey With Us</h2>
            <p class="lead mb-4">Take the first step towards providing your child with an education that nurtures both academic excellence and character development.</p>
            <div class="d-flex justify-content-center gap-3">
                <a href="<?= SITE_URL ?>/contact.php" class="btn btn-light btn-lg">Contact Us</a>
                <a href="#" class="btn btn-outline-light btn-lg" data-bs-toggle="modal" data-bs-target="#applicationModal">Apply Now</a>
            </div>
        </div>
    </section>
</main>

<?php
// Include footer
require_once 'includes/footer.php';
?> 