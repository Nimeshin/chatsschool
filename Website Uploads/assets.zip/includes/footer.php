<?php
declare(strict_types=1);

/**
 * Footer Template
 * 
 * @package SathyaSaiSchool
 */

if (!defined('ROOT_PATH')) {
    exit('Direct script access denied.');
}
?>
    <!-- Main Content End -->
    
    <!-- Footer -->
    <footer class="site-footer bg-light py-5 mt-5">
        <div class="container">
            <div class="row">
                <!-- Contact Information -->
                <div class="col-lg-4 mb-4">
                    <h5 class="mb-4">Contact Us</h5>
                    <div class="contact-info">
                        <div class="d-flex mb-3">
                            <i class="fa-solid fa-location-dot me-3 mt-1 text-primary"></i>
                            <div>
                                <p class="mb-0">98 Powerline Street<br>
                                <span class="ps-0">Westcliff, Chatsworth<br>
                                Durban, 4030</span></p>
                            </div>
                        </div>
                        <div class="d-flex mb-3">
                            <i class="fa-solid fa-phone me-3 mt-1 text-primary"></i>
                            <div>
                                <a href="tel:0314027149" class="text-decoration-none">031 402 7149</a>
                            </div>
                        </div>
                        <div class="d-flex mb-3">
                            <i class="fa-solid fa-envelope me-3 mt-1 text-primary"></i>
                            <div>
                                <a href="mailto:saischoolchats@gmail.com" class="text-decoration-none">saischoolchats@gmail.com</a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div class="col-lg-4 mb-4">
                    <h5 class="mb-4">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <i class="fa-solid fa-chevron-right me-2 text-primary"></i>
                            <a href="<?= SITE_URL ?>/about.php">About Us</a>
                        </li>
                        <li class="mb-2">
                            <i class="fa-solid fa-chevron-right me-2 text-primary"></i>
                            <a href="<?= SITE_URL ?>/academics.php">Academics</a>
                        </li>
                        <li class="mb-2">
                            <i class="fa-solid fa-chevron-right me-2 text-primary"></i>
                            <a href="<?= SITE_URL ?>/admissions.php">Admissions</a>
                        </li>
                        <li class="mb-2">
                            <i class="fa-solid fa-chevron-right me-2 text-primary"></i>
                            <a href="<?= SITE_URL ?>/contact.php">Contact</a>
                        </li>
                    </ul>
                </div>
                
                <!-- Connect With Us -->
                <div class="col-lg-4 mb-4">
                    <h5 class="mb-4">Connect With Us</h5>
                    <div class="social-links mb-4">
                        <a href="#" class="social-link me-3" title="Facebook">
                            <i class="fa-brands fa-facebook fa-2x"></i>
                        </a>
                        <a href="#" class="social-link me-3" title="Twitter">
                            <i class="fa-brands fa-twitter fa-2x"></i>
                        </a>
                        <a href="#" class="social-link me-3" title="Instagram">
                            <i class="fa-brands fa-instagram fa-2x"></i>
                        </a>
                        <a href="#" class="social-link me-3" title="YouTube">
                            <i class="fa-brands fa-youtube fa-2x"></i>
                        </a>
                    </div>
                    <div class="school-hours">
                        <h6 class="text-primary mb-3"><i class="fa-regular fa-clock me-2"></i>School Hours</h6>
                        <div class="d-flex align-items-center mb-2">
                            <i class="fa-regular fa-calendar-days me-2 text-primary"></i>
                            <span>Monday - Friday</span>
                        </div>
                        <div class="d-flex align-items-center">
                            <i class="fa-regular fa-clock me-2 text-primary"></i>
                            <span>7:30 AM - 2:30 PM</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Copyright -->
            <div class="row mt-4 pt-4 border-top">
                <div class="col-12 text-center">
                    <p class="mb-0">&copy; <?= date('Y') ?> <?= escape_html(SITE_NAME) ?>. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js"></script>
</body>
</html> 