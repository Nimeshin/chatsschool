<?php
declare(strict_types=1);

/**
 * Contact Form Handler
 * 
 * @package SathyaSaiSchool
 */

// Include configuration
require_once 'config.php';

// Initialize response array
$response = [
    'success' => false,
    'message' => ''
];

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $response['message'] = 'Invalid request. Please try again.';
        echo json_encode($response);
        exit;
    }

    // Sanitize and validate input
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $subject = filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_STRING);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);

    // Validate required fields
    if (!$name || !$email || !$subject || !$message) {
        $response['message'] = 'Please fill in all required fields.';
        echo json_encode($response);
        exit;
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['message'] = 'Please enter a valid email address.';
        echo json_encode($response);
        exit;
    }

    // Prepare email content
    $to = ADMIN_EMAIL;
    $email_subject = "New Contact Form Submission: " . $subject;
    
    $email_body = "You have received a new message from the contact form.\n\n";
    $email_body .= "Name: " . $name . "\n";
    $email_body .= "Email: " . $email . "\n";
    if ($phone) {
        $email_body .= "Phone: " . $phone . "\n";
    }
    $email_body .= "Subject: " . $subject . "\n\n";
    $email_body .= "Message:\n" . $message . "\n";

    // Basic email headers
    $headers = "";
    $headers .= "From: " . SITE_NAME . " <admin@healthrevolutions.co.za>\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();

    // Send email
    try {
        if (mail($to, $email_subject, $email_body, $headers)) {
            // Send auto-reply to user
            $auto_reply_subject = "Thank you for contacting " . SITE_NAME;
            $auto_reply_message = "Dear " . $name . ",\n\n";
            $auto_reply_message .= "Thank you for contacting us. We have received your message and will respond as soon as possible.\n\n";
            $auto_reply_message .= "Best regards,\n";
            $auto_reply_message .= SITE_NAME . " Team";

            // Auto-reply headers
            $auto_headers = "";
            $auto_headers .= "From: " . SITE_NAME . " <admin@healthrevolutions.co.za>\r\n";
            $auto_headers .= "Reply-To: " . ADMIN_EMAIL . "\r\n";
            $auto_headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
            $auto_headers .= "X-Mailer: PHP/" . phpversion();

            mail($email, $auto_reply_subject, $auto_reply_message, $auto_headers);

            $response['success'] = true;
            $response['message'] = 'Thank you for your message. We will get back to you soon.';
        } else {
            throw new Exception('Failed to send email');
        }
    } catch (Exception $e) {
        error_log('Contact Form Error: ' . $e->getMessage());
        $response['message'] = 'Sorry, there was an error sending your message. Please try again later.';
    }
} else {
    $response['message'] = 'Invalid request method.';
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response); 